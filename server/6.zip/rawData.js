exports.insectTress = [
	{
		insect: { name: "Western Pygmy Blue Butterfly" },
		trees: [
			{ tree: "General Sherman" },
			{ tree: "General Grant" },
			{ tree: "Lincoln" },
			{ tree: "Stagg" },
		],
	},
	{
		insect: { name: "Patu Digua Spider" },
		trees: [{ tree: "Stagg" }],
	},
];
